function [T_matrix] = TMatrixGeneration(f)
addpath('.\2D_MRA_Deconvolution');
addpath('.\3D_Comlex Dual Tree_Denoising')
addpath('.\3D_Framelet_Denoising')
addpath('.\Basic_Operation')
[m,n]=size(f);
L=5;
Dec = FrameletDec(f,L);
Rec = FrameletRec(Dec,L);
B=Dec;
B{1,L}{1,1}=0;
B_fan=FrameletRec(B,L);
T_matrix=f-B_fan;
end

