function [f,fun_all] = DeepMRAFISTA_Core(g,PSF,W1,WT1,W2,WT2,W3,WT3,lambda_framelet,lambda_curvelet,lambda_x,k,av,typer,option1,option2,Maxiteration,sig,flag1,flag11)
    [m,n]=size(g);
    d=min(m,n);
    center=[fix(d/2),fix(d/2)];
    center=single(center);
    PSF=padPSF(PSF,[m,n]);
    [m,n]=size(g);
    PSF=padPSF(PSF,m,n);
    trans=@(X) 1/sqrt(m*n)*fft2(X);
    itrans=@(X) sqrt(m*n)*ifft2(X);       
    Sbig=fft2(circshift(PSF,1-center));
    Btrans=trans(g);
    L=2*max(max(abs(Sbig).^2));

% initialization
X_iter=g;
Y=X_iter;
t_new=1;
ratio=1;
lambda1=single(lambda_framelet);
lambda2=single(lambda_curvelet);
lambda3=single(lambda_x);

if flag1~=1&&flag11~=1
    if max(lambda1,lambda2)<=1e-3
        interval=20;
    elseif max(lambda1,lambda2)<=6.1e-3
        interval=10;
    else
        interval=1;
    end
else
        interval=1;
end


X_iter=single(X_iter);
t_new=single(t_new);
Y=single(Y);
L=single(L);

if typer==1
fr=single(0.8);
else
   fr=single(0.2); 
end
constant=single(0.2); 
fun_all=norm(Sbig.*trans(X_iter)-Btrans,'fro')^2;
h2 = waitbar(0,'Single frame 2D-MRA processing');
%% Bias thresholding
if option1==1
    if sig==1
        fprintf('**Bias soft-thresholding**\n');
    end
  for i=1:Maxiteration
    % Store the old value of the iterate and the t-constant
   X_old=X_iter;
   t_old=t_new;  
    % Gradient step
    D=Sbig.*trans(Y)-Btrans;
    Y=Y-2/L*itrans(conj(Sbig).*D);
    Y=real(Y);  
    X_iter=Y;  
   if i==1||mod(i,interval)==0
    WF=W1(Y);  
    [~,m]=size(WF);
    for ii=1:m
            tmp1=WF{1,ii};
            [dx,dy]=size(tmp1);
            for jj=1:dx
                for kk=1:dy
                tmp=tmp1{jj,kk};
    D=abs(tmp)-lambda1/(L);
    tmp=sign(tmp).*((D>0).*D);
    WF{1,ii}{jj,kk}=tmp;
                end
            end       
    end
    X_iter=WT1(WF);
    WC=W2(X_iter);
    [m,n]=size(WC);
    for ii=1:m
        for jj=1:n
            tmp1=WC{ii,jj};
            z=length(tmp1);
            for kk=1:z
                tmp=tmp1{1,kk};
    D=abs(tmp)-lambda2/(L);
    tmp=sign(tmp).*((D>0).*D);
    WC{ii,jj}{1,kk}=tmp;
            end
        end
    end
    X_iter=WT2(WC);
     WY=W3(X_iter);
     tmp=WY;
     T_matrix1=TMatrixGeneration(WY); 
     T_matrix1=T_matrix1/max(max(T_matrix1));
     T_matrix2=WY;
     T_matrix=fr*T_matrix1+(1-fr)*(T_matrix2);
   if typer==1&&i==1  
    judge=T_matrix-av;
    mask1=double(judge<0);
    mask2=double(judge>=0);
    value2=mask2.*judge;
    modul=1.*mask1.*((1-constant)/av.*T_matrix+av)+(value2+1).^k.*mask2;
   end
   if typer==2
    judge=T_matrix-av;
    mask1=double(judge<0);
    mask2=double(judge>=0);
    value2=mask2.*judge;
    modul=1.*mask1.*((1-constant)/av.*T_matrix+av)+(value2+1).^k.*mask2;
   end
    lambda_NL=lambda3*modul;
    D=abs(tmp)-lambda_NL/(L);
    tmp=sign(tmp).*((D>0).*D);
    WY=tmp;
    X_iter=WT3(WY);
        t_new=(1+sqrt(1+4*t_old^2))/2;
    Y=X_iter+(t_old-1)/t_new*(X_iter-X_old);   
   end

     s=sprintf('Single frame 2D-MRA processing:%d',ceil(i/Maxiteration*100));
     waitbar(i/Maxiteration,h2,[s '%']);

if interval==1
   C=WF;
    t1=single(0);
    for ii=1:m
        tmper=C{1,ii};
        for jj=1:dx
            for kk=1:dy
            tmp1=tmper{jj,kk};          
            t1=t1+sum(sum(abs(tmp1)));
            end
        end
    end
    C=WC;
    t2=single(0);
    [m,n]=size(C);
    for ii=1:m
        for jj=1:n
            tmp1=C{ii,jj};
            z=length(tmp1);
            for kk=1:z
            tmp=tmp1{1,kk};
            t2=t2+sum(sum(abs(tmp)));
            end
        end
    end
 t3=sum(sum(abs(lambda_NL.*Y)));
 fun_val=t3;
 fun_val2=lambda1*t1+lambda2*t2+norm(Sbig.*trans(X_iter)-Btrans,'fro')^2;
    if i>1
        ratio=abs(fun_val-fun_old)/fun_old;
        ratio2=abs(fun_val2-fun_old2)/fun_old2;
    end
    if ratio<0.001&&i>5&&ratio2<0.001
        fun_all=[fun_all,norm(Sbig.*trans(X_iter)-Btrans,'fro')^2];
       s=sprintf('Single frame 2D-MRA processing:%d',ceil(100));
       waitbar(i/Maxiteration,h2,[s '%']);
        break
    end
    fun_old=fun_val;
    fun_old2=fun_val2;
end
  end
          fun_all=[fun_all,norm(Sbig.*trans(X_iter)-Btrans,'fro')^2];
end
close(h2);
f=X_iter;
