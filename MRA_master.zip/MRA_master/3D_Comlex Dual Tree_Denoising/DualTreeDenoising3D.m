function [f_stack] = DualTreeDenoising3D(g_stack,lambda1)
%% To satisfy Dual Tree condition
fprintf('**3D DTCW denoising starting**\n');
f_stack=double(g_stack);
[mm,nn,z]=size(f_stack);

diff1=mod(mm,4);
diff2=mod(nn,4);
diff3=mod(z,4);

g_stack=zeros(mm+4-diff1,nn+4-diff2,z+4-diff3);
g_stack=double(g_stack);
g_stack(1:mm,1:nn,1:z)=f_stack;
clear f_stack

%% Do 3D Complex Dual Tree transform 
gg_stack=g_stack;
% m=max(max(max(gg_stack)));
% mi=min(min(min(gg_stack)));
% gg_stack=(gg_stack-mi)/(m-mi);

% [d1,d2,d3]=size(gg_stack);
% for i=1:d3
%         m=max(max(gg_stack(:,:,i)));
%     mi=min(min(gg_stack(:,:,i)));
%     gg_stack(:,:,i)=(gg_stack(:,:,i)-mi)/(m-mi);
% end


[Faf, Fsf] = FSfarras;
[af, sf] = dualfilt1;
J=2;
w=cplxdual3D(gg_stack, J, Faf, af);

%% Soft thresholding
[~,suby1]=size(w);
for i=1:suby1-1
    w_sub1=w{1,i};
    [subx2,suby2]=size(w_sub1);
    for ii=1:suby2
        w_sub2=w_sub1{1,ii};
        [subx3,suby3]=size(w_sub2);
        for iii=1:suby3
            w_sub3=w_sub2{1,iii};
            [subx4,suby4]=size(w_sub3);
            for iiii=1:suby4
                w_sub4=w_sub3{1,iiii};
                [subx5,suby5]=size(w_sub4);
                for iiiii=1:suby5
                    w_sub5=w_sub4{1,iiiii};
                    [finalx,finaly,finalz]=size(w_sub5);
                    for k=1:finalz
                       T=w_sub5(:,:,k);
                       D=abs(T)-lambda1;
                       T=sign(T).*((D>0).*D);
                       w_sub5(:,:,k)=T;
                    end
                    w{1,i}{1,ii}{1,iii}{1,iiii}{1,iiiii}=w_sub5;
                end
            end
        end
    end
end
       w_sub1=w{1,3};
       [subx2,suby2]=size(w_sub1);
       for ii=1:suby2
        w_sub2=w_sub1{1,ii};
        [subx3,suby3]=size(w_sub2);
      
        for iii=1:suby3
            w_sub3=w_sub2{1,iii};
            [subx4,suby4]=size(w_sub3);
    
               for iiii=1:suby4
                w_sub4=w_sub3{1,iiii};
                [finalx,finaly,finalz]=size(w_sub4);
                 for k=1:finalz
                       T=w_sub4(:,:,k);
                       D=abs(T)-lambda1;
                       T=sign(T).*((D>0).*D);
                       w_sub4(:,:,k)=T;
                 end
                  w{1,3}{1,ii}{1,iii}{1,iiii}=w_sub4;
               end
        end
      end
       
%% Do Inverse 3D Dual Tree transform
 Rec = icplxdual3D(w, J, Fsf, sf);
 f_stack=Rec(1:mm,1:nn,1:z);
 fprintf('**3D DTCW denoising completed**\n');
end

