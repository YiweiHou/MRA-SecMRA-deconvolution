function [f_stack] = BackgroundSubtraction(f_stack,k,lambda,gpu,typer)
%% Initilization
fprintf('**Debackground starting**\n');
 f_stack=single(f_stack);
 k=single(k);
 lambda=single(lambda);
 [m,n,d3]=size(f_stack);


%% Padding zeros
[d1,d2,d3]=size(f_stack);

%% GPU Accerlation
if gpu==1
f_stack=gpuArray(f_stack);
cudaAvailable
end
num=20;
%% De-background
av=0.2;
constant=single(0.2); 
iter=5;
lambda=lambda/iter;
if typer==1
fr=single(0.8);
else
fr=single(0.3);
end

% iteration
    h = waitbar(0,'Pre-debackground processing');
for i=1:d3
f=f_stack(:,:,i);
f=single(f);
f=f/max(max(f));
% Start iteration
     for ii=1:iter
% Generating bias matrix
     T_matrix1=TMatrixGeneration(f); 
     T_matrix1=T_matrix1/max(max(T_matrix1));
     T_matrix2=f;
     T_matrix=fr*T_matrix1+(1-fr)*(T_matrix2);
     judge=T_matrix-av;
     mask1=single(judge<0);
     mask2=single(judge>=0);
     value2=mask2.*judge;
     modul=1.*mask1.*((1-constant)/av.*T_matrix+av)+(value2+1).^k.*mask2;
     lambda_NL=lambda*modul;
% Subtract background
     D=abs(f)-lambda_NL;
     f=sign(f).*((D>0).*D);
     end
    f_stack(:,:,i)=f;
    if i==1
    figure(98); imshow(f(num+1:end-num,num+1:end-num,1),[]); title('Frame1: Debackground'); pause(0.5)
    end
    fprintf('Debackground: %05.1f %% complete\n',i/d3*single(100));
         s=sprintf('Pre-debackground processing:%d',ceil(i/d3*100));
             waitbar(i/d3,h,[s '%']);
end
close(h);
f_stack=gather(f_stack);
fprintf('**Debackground completed**\n');
end

