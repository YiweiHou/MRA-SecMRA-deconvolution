function [] = writeMTiffn(f_stack,filename,n)
stackfilename = filename;
[~,~,z]=size(f_stack);
% m=max(max(max(f_stack)));
% mi=min(min(min(f_stack)));
for k = 1:z
    X=f_stack(:,:,k);
    X=double(X);
    m=max(max(X));
    mi=min(min(X));
    if n==8
    X=(X-mi)*(2^8-1)/(m-mi);
    imwrite(uint8(X), stackfilename, 'WriteMode','append') % 写入stack图像
    elseif n==16
    X=(X-mi)*(2^16-1)/(m-mi);
    imwrite(uint16(X), stackfilename, 'WriteMode','append') % 写入stack图像
    else
            X=(X-mi)*(2^32-1)/(m-mi);
    imwrite(uint32(X), stackfilename, 'WriteMode','append') % 写入stack图像
    end
end

