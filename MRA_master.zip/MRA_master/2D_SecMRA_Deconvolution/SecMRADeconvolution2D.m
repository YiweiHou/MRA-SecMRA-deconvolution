function [f] = SecMRADeconvolution2D(g,PSF,lambda_framelet,lambda_curvelet,lambda_x,RLtime,k,av,typer,option1,option2,sig)
%% Pre-process
    g=single(g);
    [~,~,d3]=size(g);

%% Definition of the waveform
    wav1=@(U)FrameletDec(U,2);
    iwav1=@(C)FrameletRec(C,2);
    wav2 = @(X)CurveletDec(X,1,2); 
    iwav2 =@(C)real(CurveletRec(C,1));
    wav3=@(U)U;
    iwav3=@(U)U;
    if max(lambda_framelet,lambda_curvelet)<=5e-3
    Maxiteration=100;
    else
    Maxiteration=50;
    end

%% Substract single frame and deconvolute
for i=1:d3
    gg=g(:,:,i);
    m=max(max(gg));
    mi=min(min(gg));
    gg=(gg-mi)/(m-mi);
    [g_out]=SecMRAFISTA_Core(gg,PSF,wav1,iwav1,wav2,iwav2,wav3,iwav3,lambda_framelet,lambda_curvelet,lambda_x,k,av,typer,option1,option2,Maxiteration,sig);
    g_out = deconvlucy(g_out,PSF,RLtime);
    g(:,:,i)=g_out;
    fprintf('%05.1f %% complete\n',i/d3*100);
end
%% Return
   f=g;
end

