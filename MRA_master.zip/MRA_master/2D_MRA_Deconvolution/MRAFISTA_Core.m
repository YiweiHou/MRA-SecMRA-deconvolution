function [f,fun_all]=MRAFISTA_Core(g,PSF,center,W1,WT1,W2,WT2,lambda1,lambda2,Maxiteration,flag1,flag11)
% Assigning parameters according to pars and/or default values
    [m,n]=size(g);
    PSF=padPSF(PSF,m,n);

        trans=@(X) 1/sqrt(m*n)*fft2(X);
        itrans=@(X) sqrt(m*n)*ifft2(X);
        % computng the eigenvalues of the blurring matrix         
        Sbig=fft2(circshift(PSF,1-center));
% computng the eigenvalues of the blurring matrix  
%     trans=@(X)dct2(X);
%     itrans=@(X)idct2(X);
%     e1=zeros(m,n);
%     e1(1,1)=1;
%     Sbig=dct2(dctshift(PSF,center))./dct2(e1);
% computing the two dimensional transform of Bobs
    Btrans=trans(g);
%The Lipschitz constant of the gradient of ||A(X)-Bobs||^2
    L=2*max(max(abs(Sbig).^2));
% initialization
    f_iter=g;
    Y=f_iter;
    t_new=1;

%Rationalize the soft-thresholding weights
if flag1~=1&&flag11~=1
    if max(lambda1,lambda2)<=1e-4
        interval=40;
    elseif max(lambda1,lambda2)<=1e-3
        interval=20;
    elseif max(lambda1,lambda2)<=8e-3
        interval=10;
    else
        interval=1;
    end
else
    interval=1;
end

fun_all=norm(Sbig.*trans(f_iter)-Btrans,'fro')^2;
h2 = waitbar(0,'Single frame 2D-MRA processing');
for i=1:Maxiteration
    % Store the old value of the iterate and the t-constant
    f_old=f_iter;
    t_old=t_new;
    % Gradient step
    D=Sbig.*trans(Y)-Btrans;
    Y=Y-2/L*itrans(conj(Sbig).*D);
    Y=real(Y);  
    f_iter=Y;

 %% Transform1 soft-thresholding
 if i==1||mod(i,interval)==0
    % Framelet transform
    WX=W1(Y);
    % Soft thresholding 
    [~,m]=size(WX);
    for ii=1:m
            tmp1=WX{1,ii};
            [dx,dy]=size(tmp1);
            for jj=1:dx
                for kk=1:dy
                tmp=tmp1{jj,kk};
    D=abs(tmp)-lambda1/(L);
    tmp=sign(tmp).*((D>0).*D);
    WX{1,ii}{jj,kk}=tmp;
                end
            end       
    end
    % The new iterate inverse wavelet transform of WY
    f_iter=WT1(WX);
%% Transform2 soft-thresholding
    % Curvelet transform
    WY=W2(f_iter);
    % Soft thresholding 
    [m,n]=size(WY);
    for ii=1:m
        for jj=1:n
            tmp1=WY{ii,jj};
            z=length(tmp1);
            for kk=1:z
                tmp=tmp1{1,kk};
    D=abs(tmp)-lambda2/(L);
    tmp=sign(tmp).*((D>0).*D);
    WY{ii,jj}{1,kk}=tmp;
            end
        end
    end
    % The new iterate inverse wavelet transform of WY
    f_iter=WT2(WY);
    %updating t and Y
    t_new=(1+sqrt(1+4*t_old^2))/2;
    Y=f_iter+(t_old-1)/t_new*(f_iter-f_old);

 end
     s=sprintf('Single frame 2D-MRA processing:%d',ceil(i/Maxiteration*100));
     waitbar(i/Maxiteration,h2,[s '%']);
%% Penalty Cal
if interval==1
% Framelet
    C=WX;
    t1=0;
    for ii=1:m
        tmper=C{1,ii};
        for jj=1:dx
            for kk=1:dy
            tmp1=tmper{jj,kk};          
            t1=t1+sum(sum(abs(tmp1)));
            end
        end
    end
% Curvelet
    C=WY;
    t2=0;
    [m,n]=size(C);
    for ii=1:m
        for jj=1:n
            tmp1=C{ii,jj};
            z=length(tmp1);
            for kk=1:z
            tmp=tmp1{1,kk};
            t2=t2+sum(sum(abs(tmp)));
            end
        end
    end

    fun_val=norm(Sbig.*trans(f_iter)-Btrans,'fro')^2+lambda1*t1+lambda2*t2;

    if i>1
        ratio=abs(fun_val-fun_old)/fun_old;
    if ratio<0.0001&&i>1
        fun_all=[fun_all,norm(Sbig.*trans(f_iter)-Btrans,'fro')^2];
       s=sprintf('Single frame 2D-MRA processing:%d',ceil(100));
       waitbar(i/Maxiteration,h2,[s '%']);
        break
    end
    end
    fun_old=fun_val;
end
end
close(h2);
fun_all=[fun_all,norm(Sbig.*trans(f_iter)-Btrans,'fro')^2];
f_iter(f_iter<0)=0;
f=f_iter;
