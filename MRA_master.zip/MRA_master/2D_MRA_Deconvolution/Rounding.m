function [para] = Rounding(para)
%UNTITLED4 此处显示有关此函数的摘要
%   此处显示详细说明
if para>=1e-2
    count=0;
    while para<1
        para=para*10;
        count=count+1;
    end
    para=para*10;
    para=round(para);
    para=para/10^(count+1);
else
        count=0;
    while para<1
        para=para*10;
        count=count+1;
    end
    para=round(para);
    para=para/10^(count);
end
end

