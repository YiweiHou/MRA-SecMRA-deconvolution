function [f,fun_all] = MRADeconvolution2D(g,PSF,lamda_framelet,lamda_curvelet,RLtime,flag1,flag11)
%% Pre-process
    g=single(g);
    [d1,d2,d3]=size(g);
    f_stack=zeros(d1,d2,d3);

    [d1,d2]=size(PSF);
        d=min(d1,d2);
    center=[fix(d/2)+1,fix(d/2)+1];
    
%% Definition of the waveform
    wav1=@(U)FrameletDec(U,2);
    iwav1=@(C)FrameletRec(C,2);
    wav2 = @(X)CurveletDec(X,1,2); 
    iwav2 =@(C)real(CurveletRec(C,1));
 if flag1~=1&&flag11~=1
    if min(lamda_framelet,lamda_curvelet)<=0.0001
            Maxiteration=2000;    
    elseif min(lamda_framelet,lamda_curvelet)<=0.001
        Maxiteration=1000;
    elseif min(lamda_framelet,lamda_curvelet)<=0.002
        Maxiteration=500;
    elseif min(lamda_framelet,lamda_curvelet)<=0.01
        Maxiteration=100;
    else
        Maxiteration=50;
    end
 else
        Maxiteration=50;
 end
 

g1_stack=g;
num1=0;
num2=0;
g_stack=g;
%% Substract single frame and deconvolute
if d3>1
h = waitbar(0,'2D MRA deconvolution processing');
end
for i=1:d3
    gg=g_stack(:,:,i);
    m=max(max(gg));
    mi=min(min(gg));
    gg=(gg-mi)/(m-mi);
    sig=1;
    sparsity1=sum(sum(abs(gg)))/length(gg(:));
    [g_out,fun_all]=MRAFISTA_Core(gg,PSF,center,wav1,iwav1,wav2,iwav2,lamda_framelet,lamda_curvelet,Maxiteration,flag1,flag11);
    m=max(max(g_out));
    mi=min(min(g_out));
    g_out=(g_out-mi)/(m-mi);
    sparsity2=sum(sum(abs(g_out)))/length(g_out(:));
    if sparsity2>sparsity1
    g_out=g_out-sparsity2+sparsity1;
    g_out(g_out<0)=0;
    end
    if RLtime>0
    g_out = deconvlucy(g_out,PSF,RLtime);
    end
        if i==1
        figure(100)
        num=30;
        imshow(g_out(num+1:end-num,num+1:end-num,:),[])
        title('Frame1: 2D-MRA processed'); pause(0.2)
         end
    f_stack(:,:,i)=g_out(num1+num2+1:end-num1-num2,num1+num2+1:end-num1-num2);
    fprintf('%05.1f %% complete\n',i/d3*100);
    if d3>1
     s=sprintf('2D MRA deconvolution processing:%d',ceil(i/d3*100));
             waitbar(i/d3,h,[s '%']);
    end
        
end

if d3>1
 close(h)
end
%% Return
   f=f_stack;
end

