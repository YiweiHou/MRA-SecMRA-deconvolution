To run the .exe files, MATLAB Runtime 2020b is needed, which can be downloaded from https://ww2.mathworks.cn/products/compiler/matlab-runtime.html.

Opening the files may take several seconds.

For utilization of the software, please check User Manual